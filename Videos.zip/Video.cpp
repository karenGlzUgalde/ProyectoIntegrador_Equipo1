#include "Video.h"

#include <iostream>
#include <string>

using namespace std;

Video::Video()
{
    tipoVideo = "";
    nombreVideo = "";
    genero = "";
    id = 0;
    calificacion = 0;
    anioLanzamiento = 0;
    duracion = 0;
    pendCalif = false;
    peliOSerie = true;
}

Video::Video(string tipo, string nombre, string gen, int iD, int calif, int anio, int dur, bool pend, bool PoS)
{
    tipoVideo = tipo;
    nombreVideo = nombre;
    genero = gen;
    id = iD;
    calificacion = calif;
    anioLanzamiento = anio;
    duracion = dur;
    pendCalif = pend;
    peliOSerie = PoS;
    //nombreCompleto << nC;
}
// Getters
string Video::getTipoVideo()
{
    return tipoVideo;
}

string Video::getNombreVideo()
{
    return nombreVideo;
}

string Video::getGenero()
{
    return genero;
}

int Video::getId()
{
    return id;
}

int Video::getCalificacion()
{
    return calificacion;
}

int Video::getAnioLanzamiento()
{
    return anioLanzamiento;
}

int Video::getDuracion()
{
    return duracion;
}

bool Video::getPendCalif()
{
    return pendCalif;
}

bool Video::getPeliOSerie()
{
    return peliOSerie;
}
// Setters
void Video::setTipoVideo(string tipo)
{
    tipoVideo = tipo;
}

void Video::setNombreVideo(string nombre)
{
    nombreVideo = nombre;
}

void Video::setGenero(string gen)
{
    genero = gen;
}

void Video::setId(int id)
{
    this->id = id;
}

void Video::setCalificacion(int calif)
{
    calificacion = calif;
}

void Video::setAnioLanzamiento(int anio)
{
    anioLanzamiento = anio;
}

void Video::setDuracion(int dur)
{
    duracion = dur;
}

void Video::setPendCalif(bool pend)
{
    pendCalif = pend;
}

void Video::setPeliOSerie(bool PoS)
{
    peliOSerie = PoS;
}
// Métodos Propios
/*
int Video::calificaVideo(int calif)
{
    cout << "\nIntroduzca la calificacion que le desea asignar al video: ";
    cin >> calif;
    return calif;
}
void Video::muestraDatos()
{
    if (peliOSerie == true)
    {
        cout << "\nEs pelicula o serie?: " << "Pelicula" << endl;
    }
    else
    {
        cout << "\nEs pelicula o serie?: " << "Serie" << endl;
    }
    cout << "Tipo de Video: " << tipoVideo << endl;
    if (peliOSerie == true)
    {
        cout << "Nombre de la pelicula: " << nombreVideo << endl;
    }
    else
    {
        cout << "Nombre de la serie: " << nombreVideo << endl;
    }
    cout << "Genero: " << genero << endl;
    cout << "Id:" << id << endl;
    if (pendCalif == true)
    {
      cout << "Calificacion pendiente" << endl;
    }
    else
    {
        cout << "Calificacion: " << calificacion << " estrellas" << endl;
    }
    cout << "Anio de Lanzamiento: " << anioLanzamiento << endl;
    cout << "Duracion: " << duracion << " minutos" << endl;
}
*/