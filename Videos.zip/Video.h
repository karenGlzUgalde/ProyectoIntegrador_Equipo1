#ifndef VIDEO_H
#define VIDEO_H

#include <iostream>
#include <string>

using namespace std;

class Video
{
    public:
        Video();
        Video(string, string, string, int, int, int, int, bool, bool/*, stringstream*/);
        // Getters
        string getTipoVideo();
        string getNombreVideo();
        string getGenero();
        int getId();
        int getCalificacion();
        int getAnioLanzamiento();
        int getDuracion();
        bool getPendCalif();
        bool getPeliOSerie();
        // Setters
        void setTipoVideo(string);
        void setNombreVideo(string);
        void setGenero(string);
        void setId(int);
        void setCalificacion(int);
        void setAnioLanzamiento(int);
        void setDuracion(int);
        void setPendCalif(bool);
        void setPeliOSerie(bool);
        // Métodos Propios
        //virtual void calificaVideo(int);
    protected:
        string tipoVideo;
        string nombreVideo;
        string genero;
        int id;
        int calificacion;
        int anioLanzamiento;
        int duracion;
        bool pendCalif;
        bool peliOSerie; // Pelicula = true y Serie  = false
};

#endif // VIDEO_H
